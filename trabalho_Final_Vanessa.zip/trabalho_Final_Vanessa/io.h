#include"arvoreRN.h"
#include <stdio.h>
#include <stdlib.h>
#ifndef IO_H
#define IO_H
int contaLinhas(FILE *entrada);
int *leDados();
void percorreOrdemRN(rn *A);
#endif /* IO_H */

