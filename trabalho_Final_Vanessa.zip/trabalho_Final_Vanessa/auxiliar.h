#ifndef AUXILIAR_H
#define AUXILIAR_H

void converteArvore(arvoreB *arvore234, rn *arvoreRN);


#endif /* AUXILIAR_H */

